# RANSOMWARE-WANNACRY-2.0
Yes that's what you thinking

PWD: infected
